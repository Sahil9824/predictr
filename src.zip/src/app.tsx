import MainNavigation from "./navigation/MainNavigation";

const App = () => {
  return (
    <>
      <MainNavigation />
    </>
  )
}

export default App;