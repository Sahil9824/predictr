import 'react-native-gesture-handler';
import App from './app';

const Setup = () => {
  return (
    <>
      <App />
    </>
  )
}

export default Setup;