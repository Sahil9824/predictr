export const Images = {
  trophies: require('./trophies.png'),
  signinWithGoogle: require('./signinWithGoogle.png'),
  signinWithEmail: require('./signWithEmail.png'),
  back: require('./back.png'),
  eyeClosed: require('./eye.png'),
  avatarPlaceholder: require('./avatarPlaceholder.png'),
  camera: require('./camera.png'),
  avatar1: require('./Avatars1.png'),
  avatar2: require('./Avatars2.png'),
  avatar3: require('./Avatars3.png'),
  avatar4: require('./Avatars4.png'),
};
